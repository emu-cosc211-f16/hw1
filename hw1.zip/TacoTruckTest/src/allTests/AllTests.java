package allTests;


import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import tools.CashierTest;
import tools.TacoTruckConstantsTest;
import food.*;


	@RunWith(Suite.class)
	@SuiteClasses({
		TacoTruckConstantsTest.class,
		ChurroSundaeTest.class,
		ChurroTest.class,
		FoodItemTest.class,
		RiceAndBeansTest.class,
		TacoTest.class,
		CashierTest.class
	})
	public class AllTests{
		
	}

