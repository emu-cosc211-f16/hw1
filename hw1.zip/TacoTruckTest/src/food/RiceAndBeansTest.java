package food;
import org.junit.Test;
import junit.framework.TestCase;

public class RiceAndBeansTest extends TestCase {

	@Test
	public void testRiceAndBeansExtendsFoodItem() {
		assertSame(FoodItem.class, RiceAndBeans.class.getSuperclass());
	}
	
	@Test
	public void testConstructor() {
		String name = "Rice And Beans";
		double weight = 3.42;
		double pricePerPound = 4.99;
		
		RiceAndBeans riceAndBeans = new RiceAndBeans(name, weight, pricePerPound);
		
		assertEquals(name, riceAndBeans.getName());
		assertEquals(weight, riceAndBeans.getWeight(),0);
		assertEquals(pricePerPound, riceAndBeans.getPricePerPound(),0);
		
		int expectedCostInCents = 1707;
		
		assertEquals(expectedCostInCents, riceAndBeans.getCost());
		
		name = "rice, beans, and cilantro";
		weight = .8;
		pricePerPound = .89;
		
		RiceAndBeans riceAndBeans2 = new RiceAndBeans(name, weight, pricePerPound);
		
		assertEquals(name, riceAndBeans2.getName());
		assertEquals(weight, riceAndBeans2.getWeight(),0);
		assertEquals(pricePerPound, riceAndBeans2.getPricePerPound(),0);
		
		expectedCostInCents = 71;
		
		assertEquals(expectedCostInCents, riceAndBeans2.getCost());
		
		
	}
	
	
}
