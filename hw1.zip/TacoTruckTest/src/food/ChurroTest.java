package food;
import org.junit.Test;
import junit.framework.TestCase;

public class ChurroTest extends TestCase  {

	@Test
	public void testChurroExtendsFoodItem() {
		assertSame(FoodItem.class, Churro.class.getSuperclass());
	}
	
	@Test
	public void testConstructor() {
		String name = "Churro";
		double cost = 3.42;
		int expectedCost = 342;
		
		Churro churro = new Churro(name, cost);
		assertEquals(name, churro.getName());
		assertEquals(expectedCost, churro.getCost());
		
		name = "cinammon churro";
		cost = 1233.445;
		expectedCost = 123345;
		
		Churro churro2 = new Churro(name, cost);
		assertEquals(name, churro2.getName());
		assertEquals(expectedCost, churro2.getCost());
		
		name = "churro";
		cost = -4.5;
		expectedCost = -450;
		
		Churro churro3 = new Churro(name, cost);
		assertEquals(name, churro3.getName());
		assertEquals(expectedCost, churro3.getCost());
		
	}
}
