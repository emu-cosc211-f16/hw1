package food;
import java.lang.reflect.Modifier;
import org.junit.Test;
import junit.framework.TestCase;

public class FoodItemTest extends TestCase {

	@Test
	public void testFoodItemIsAbstract(){
		assertTrue(Modifier.isAbstract(FoodItem.class.getModifiers()));
	}
	
}
