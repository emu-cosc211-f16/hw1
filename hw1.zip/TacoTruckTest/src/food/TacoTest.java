package food;
import org.junit.Test;
import junit.framework.TestCase;

public class TacoTest extends TestCase {

	@Test
	public void testTacoExtendsFoodItem() {
		assertSame(FoodItem.class,Taco.class.getSuperclass());
	}
	
	@Test
	public void testConstructor() {
		String name = "shrimp taco";
		int amount = 4;
		double price = 2.5;
		Taco taco = new Taco(name, amount, price);
		assertEquals(name, taco.getName());
		assertEquals(amount, taco.getAmount());
		assertEquals(price, taco.getPricePerTaco(),0);
		
		int expectedCostInCents = 1000;
		
		assertEquals(expectedCostInCents, taco.getCost());
		
		name = "carnitas!";
		amount = 1;
		price = 3;
		Taco taco2 = new Taco(name, amount, price);
		
		assertEquals(name, taco2.getName());
		assertEquals(amount, taco2.getAmount());
		assertEquals(price, taco2.getPrice(),0);
		
		expectedCostInCents = 300;
		
		assertEquals(expectedCostInCents, taco2.getCost());
		
		name = "carnitas!";
		amount = 7;
		price = 3.9;
		Taco taco3 = new Taco(name, amount, price);
		
		assertEquals(name, taco3.getName());
		assertEquals(amount, taco3.getAmount());
		assertEquals(price, taco3.getPrice(),0);
		
		expectedCostInCents = 2730;
		
		assertEquals(expectedCostInCents, taco3.getCost());
		
		
	}
	
	
}
