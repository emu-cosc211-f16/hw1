package food;
import org.junit.Test;
import junit.framework.TestCase;

public class ChurroSundaeTest extends TestCase  {

	@Test
	public void testChurroSundaeExtendsChurro() {
		assertSame(Churro.class, ChurroSundae.class.getSuperclass());
	}
	
	@Test
	public void testChurroSundaeConstructor() {
		
		String name = "Cherry Churro Sundae";
		double cost = 1.5;
		double toppingCost = 2;
		ChurroSundae churroSundae = new ChurroSundae(name, cost, toppingCost);
	
		int expectedCost = 350;
		
		assertEquals(name, churroSundae.getName());
		assertEquals(toppingCost,churroSundae.getToppingCost(),0);
		assertEquals(expectedCost, churroSundae.getCost());
		
		name = "Chocolate Churro Sundae";
		cost = 3;
		toppingCost = 3.3;
		
		expectedCost = 630;
		
		ChurroSundae churroSundae2 = new ChurroSundae(name, cost, toppingCost);
		
		assertEquals(name, churroSundae2.getName());
		assertEquals(toppingCost,churroSundae2.getToppingCost(),0);
		assertEquals(expectedCost, churroSundae2.getCost());
	}
	
	
	
}
