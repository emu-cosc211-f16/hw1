package tools;

import static org.junit.Assert.*;

import org.junit.Test;

import food.*;

public class CashierTest {

	@Test
	public void testCashier() {
		Cashier cashier = new Cashier();
		
		String churroName = "Churro-licious";
		double churroCost = 2.5;
		cashier.enterItemIntoOrder(new Churro(churroName, churroCost));
		
		
		String riceAndBeansName = "Simple Rice and Beans";
		double riceAndBeansWeight = 5.1;
		double riceAndBeansPricePerPound = 3.5;
		cashier.enterItemIntoOrder(new RiceAndBeans(riceAndBeansName, riceAndBeansWeight, riceAndBeansPricePerPound));
		
		
		String tacoName = "Barbacoa Tacos";
		int tacoAmount = 7;
		double tacoPrice = 1.5;
		cashier.enterItemIntoOrder(new Taco(tacoName, tacoAmount, tacoPrice));
		
		int expectedTax = 201;
		int expectedCostBeforeTax = 3085;
		assertEquals(3, cashier.getNumberOfItemsInOrder());
		assertEquals(expectedTax,cashier.getTax());
		assertEquals(expectedCostBeforeTax,cashier.getTotalCostBeforeTax());
		String total = TacoTruckConstants.convertCentsToDollars(expectedCostBeforeTax + expectedTax);
		assertEquals(total ,cashier.getTotal());
	
		
		/*
		 * TOSTRING TEST OF ORDER SO FAR
		 * 
		 * 
		 * 
		String churroPriceString = TacoTruckConstants.convertCentsToDollars((int)Math.round(churroCost*100));
		String riceAndBeansPriceString = TacoTruckConstants.convertCentsToDollars((int) Math.round(riceAndBeansPricePerPound *riceAndBeansWeight * 100));
		String tacoPriceString = TacoTruckConstants.convertCentsToDollars((int) Math.round(tacoAmount*tacoPrice*100));
		
		String expectedReceipt = "RECEIPT:\n" + churroName + ", " + churroPriceString + "\n" +
						riceAndBeansName + ", " + riceAndBeansPriceString + "\n" +
						tacoName + ", " + tacoPriceString + "\n" +
						"TOTAL: " + total;
		
		assertEquals(expectedReceipt, cashier.toString());
		*/
		
		
		cashier.clearOrder();
		
		assertEquals(0, cashier.getNumberOfItemsInOrder());
		
		churroCost = 3.3;
		double toppingCost = 2.7;
		String churroSundaeName = "Choc Chip Churro";
		cashier.enterItemIntoOrder(new ChurroSundae(churroSundaeName, churroCost,  toppingCost));
		
		assertEquals(1, cashier.getNumberOfItemsInOrder());
		
		expectedCostBeforeTax = (int) Math.round((churroCost + toppingCost)*100);
		expectedTax = (int) Math.round(expectedCostBeforeTax*TacoTruckConstants.TAX/100);
		assertEquals(expectedTax,cashier.getTax());
		assertEquals(expectedCostBeforeTax,cashier.getTotalCostBeforeTax());
		
		total = TacoTruckConstants.convertCentsToDollars(expectedCostBeforeTax + expectedTax);
		
		assertEquals(total, cashier.getTotal());
		
		/*
		 * TOSTRING TEST OF NEW ORDER
		 * 
		 * 
		 * 
		String churroSundaePriceString = TacoTruckConstants.convertCentsToDollars(expectedCostBeforeTax); 
		expectedReceipt = "RECEIPT:\n" + churroSundaeName + ", " + churroSundaePriceString + "\n" 
						+ "TOTAL: " + total;
		
		assertEquals(expectedReceipt, cashier.toString());
		*/
		
	}
}
