package tools;
import org.junit.Test;

import junit.framework.TestCase;
import tools.TacoTruckConstants;

public class TacoTruckConstantsTest extends TestCase {

	@Test
	public void testConvertCentsToDollars(){
		int cents1 = 399;
		int cents2 = 1099;
		int cents3 = 1405;
		int cents4 = 99;
		
		int cents5 = -99;
		int cents6 = -1099;
		int cents7 = -56705;
		
		assertEquals("3.99",TacoTruckConstants.convertCentsToDollars(cents1));
		assertEquals("10.99",TacoTruckConstants.convertCentsToDollars(cents2));
		assertEquals("14.05",TacoTruckConstants.convertCentsToDollars(cents3));
		assertEquals(".99",TacoTruckConstants.convertCentsToDollars(cents4));
		assertEquals("-.99",TacoTruckConstants.convertCentsToDollars(cents5));
		assertEquals("-10.99",TacoTruckConstants.convertCentsToDollars(cents6));
		assertEquals("-567.05",TacoTruckConstants.convertCentsToDollars(cents7));
	}
	
}
