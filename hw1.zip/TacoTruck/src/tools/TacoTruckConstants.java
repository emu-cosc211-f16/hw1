package tools;
public class TacoTruckConstants {

	public final static double TAX = 6.5;
	public final static String NAME_OF_TACO_TRUCK = "Taco Taco";
	
	public static String convertCentsToDollars(int cents){
		String dollarsInStringFormat = "";
		if (cents < 0){
			dollarsInStringFormat += "-";
			cents *= -1;
		}
		int dollars = cents/100;
		cents = cents%100;
		
		if (dollars > 0){
			dollarsInStringFormat += dollars;
		}
		
		dollarsInStringFormat += ".";
		
		if (cents < 10){
			dollarsInStringFormat += "0";
		}
		dollarsInStringFormat += cents;
		return dollarsInStringFormat;
		
	}
	
}
